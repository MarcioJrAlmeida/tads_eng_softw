# Backend

Esta pasta contém a lógica de negócio e os serviços da aplicação (Backend).

## O que deve ser salvo aqui?
- Rotas (APIs)
- Controllers e services
- Validações
- Conexão com banco de dados
- Autenticação/autorização
- Testes da API
- Configurações de ambiente (`.env.example`)