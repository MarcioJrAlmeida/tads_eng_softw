# back/config/db_config.py

MODO_DESENVOLVIMENTO = "CSV"  # ou "BD"

db_params = {
    "server": "localhost\\SQLEXPRESS",
    "database": "ifpe_sado",
    "username": "bd_sado",
    "password": "bd_admin321@",
    "driver": "ODBC Driver 17 for SQL Server"
}
