# Frontend

Esta pasta contém todo o código relacionado à interface do usuário (Frontend) do projeto.

## O que deve ser salvo aqui?
- Arquivos de interface (.html, .css, .js, etc.)
- Componentes reutilizáveis
- Scripts de UI
- Testes de interface
- Configurações específicas do front (ex: `vite.config.js`, `webpack.config.js`)