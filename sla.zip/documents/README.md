# Documentação do Projeto

Esta pasta armazena os documentos enviados e recebidos por e-mail durante o projeto, bem como a documentação oficial a ser construída.

## O que deve ser salvo aqui?
- Arquivos PDF, Word ou similares com atas de reuniões, propostas, apresentações
- Cronogramas, requisitos, brainstorms, planejamento
- Documento de especificação técnica
- Documentos de casos de uso e diagramas UML
- Versões finais da documentação técnica e funcional